import React from "react";

function AboutUs() {
  return (
    <div className="about_us_container">
      <h1>Coming soon</h1>
    </div>
  )
}

export default AboutUs
