import React from "react";
import FihrForm from "./FihrForm";

function Fihr() {
  return (
    <div className="fihr_container">
      <h1>Insert fihr stuff here</h1>
      <FihrForm/>
    </div>
  )
}

export default Fihr